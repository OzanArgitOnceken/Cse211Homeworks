#include<iostream>
#include<fstream>
#include<vector>
#include<string>
using namespace std;
class Set{
    private://actually I do not have to do it private but I want study at 241 lesson at the same time :)
        int size;//this will hold the size of the vector
        vector<char> setElements;// this will hold the elements of vector(I will do my work at one )
        vector<vector<char>> set_of_Relations;//this will hold relations like (a,a),(b,b)
        static int setCount;//this will hold how many sets in there
        int howManyElement;//this will hold how many elements in there
        bool isSymetric;//this bool statements are for check POSET easily
        bool isReflexive;
        bool isAntisymetric;
        bool isTransitive;
        bool isPoset;
        vector<int>whereisTheTransitivity;//it will hold where is transitivity and will not allow write in hasse
    public:
        Set(int a);
        void setRelationsFunc(string,int);
        void printRelations();
        void printElements();
        void setSet(string);//it means set(kurmak olan) the set(küme olan) :)
        inline int getSize(){return size;}
        inline static int getCount(){return setCount;}
        inline vector<char>getElements(){return setElements;}
        friend ostream &operator<<(ostream &,Set );
        void checkReflexive(string);
        void checkSymetric(string);
        void checkAnti(string);
        void checkTransitive(string);
        void chechkPoset(string);
        void writeNewRelationSet(string);
        void writeHasse(string);
};
int Set::setCount=0;//at the beggining we have 0 sets it will increase every read of the new set
int main()
{
    int count=0,setCount=-1;//count will say that what we should take (element count or set or relation),setcount is for which set we are in
    vector<Set> mySets;
    ifstream inputText;
    inputText.open("input.txt");//for read the input
    string line;//holds every line
    while (getline(inputText,line))//while you can take input from txt take it
    {
        if(count==0)//at starting read how many relations there will be
        {
            if(line[0]!='\0')//this if for the last line can be empty sometimes and it gives huge errors
            {
                int temp=stoi(line);//create a temp to hold the number
                mySets.push_back(temp);//convert char to int
                setCount++;//I must increase the set count because we created a set 
            }
        }
        else if(count==1)//second step read the set
        {
            mySets[setCount].setSet(line);
        }
        else//last step read all relations
        {
            int i=0;
            while (i<mySets[setCount].getSize())
            {
                mySets[setCount].setRelationsFunc(line,i);
                if(i<mySets[setCount].getSize()-1)//it is for if it is on last line do not read next line( it is number of relations of next set)
                    getline(inputText,line);
                i++;
            }
            count=-1;//make count -1 because while loop will make it 0 because I put count++
        }
        count++;
    }
    string fileName="Output.txt";//I changed name lot of while I was testing my code so I decided to change fileName string instead of every line
    ofstream writeFile;
    writeFile.open(fileName);
    writeFile.close();//At the beginning I am opening and closing the file for delete inside of the file 
    //because I use all append files so they are adding at previous one.
    for (int i = 0; i <=setCount; i++)
    {
        cout<<mySets[i]<<endl;
        string fileName="Output.txt";
        ofstream writeFile;
        writeFile.open(fileName, ios::app);//with ios::app I can add new lines instead of delete all file and write a new file
        writeFile<<"n"<<endl;//pdf says that add n so I put n instead of i+1
        
        //writeFile<<"This is set "<<i+1<<endl;//it is for read easily but pdf wants n instead of i+1
        
        mySets[i].checkReflexive(fileName);//but this functions writes at the file
        mySets[i].checkSymetric(fileName);
        mySets[i].checkAnti(fileName);
        mySets[i].checkTransitive(fileName);
        mySets[i].chechkPoset(fileName);
        mySets[i].writeNewRelationSet(fileName);
        mySets[i].writeHasse(fileName);
        writeFile<<endl<<endl;
        writeFile.close();
    }    
}
Set::Set(int a){//its just a constructor
    setCount++;//when create new object increase the count
    size=a;//make size the sented integer
}
void Set::setSet(string temp)//temp is the line
{
    howManyElement=0;//at the beggining we have 0 element
    for (int i = 0; i < temp.size(); i=i+2)//i=i+2 for do not assign (,)character to element
    {
        setElements.push_back(temp[i]);
        howManyElement++;
    }
}
void Set::printElements()
{//it is an utility function that prints the elements
    for (int i = 0; i < setElements.size(); i++)
    {
        cout<<setElements[i]<<",";
    }
    cout<<endl;
}
void Set::setRelationsFunc(string line,int i)
{
    if(set_of_Relations.empty())
    {//if it is empty create the first 
        set_of_Relations.resize(size);
        set_of_Relations[0].resize(2);
        set_of_Relations[0][0]=line[0];
        set_of_Relations[0][1]=line[2];
    }
    else
    {//if it is created before push the new one
        set_of_Relations[i].resize(2);
        set_of_Relations[i][0]=line[0];
        set_of_Relations[i][1]=line[2];
    }
    
}
void Set::printRelations()
{//it is another utility function
    //it is harmless and helpful so I decided to not delete them
    cout<<"Relations:"<<endl;
    for (int i = 0; i < size; i++)
    {
        cout<<i+1<<":"<<set_of_Relations[i][0]<<","<<set_of_Relations[i][1]<<endl;       
    }
}
void Set::checkReflexive(string fileName)
{
    int checker=0;//at beginning we have checker (it is 0)
    ofstream file;
    file.open(fileName,ios::app);//opening file for add 
    string notReflex;//  I will hold which is not reflexive in this and print it at the file
    for (int j = 0; j <howManyElement; j++)//for check all elements
    {
        int tempChecker=checker;//tempChecker for control EVERY element
        for (int i = 0; i < size; i++)//in here I am checkink all relations for all elements
        {
            if (set_of_Relations[i][0]==setElements[j]&&set_of_Relations[i][1]==setElements[j])//this if means that if relation likes for example ve are looking for element b and the 3rd relation is (b,b) so increase the tempchecker
                checker++;
        }
        if (checker==tempChecker){//if checker did not changed this element is not reflexive
            notReflex.push_back(setElements[j]);
            set_of_Relations.resize(size+1);//in here I am adding the missing reflexive relation
            set_of_Relations[size].resize(2);
            set_of_Relations[size][0]=setElements[j];
            set_of_Relations[size][1]=setElements[j];
            size++;
            }
    }
    if (checker==howManyElement)//if reflexed relations equals to element count it means it is reflexive
    {
        isReflexive=true;//I add these at hw2 for check poset
    }
    else
    {// if it is not reflexive:
        int temp(0);//temp=0
        while (notReflex[temp]!='\0')//this while writes all not reflexive elements
        {
            temp++;//increase temp for write other element
        }
        isReflexive=false;
    }
    file.close();
}
void Set::checkSymetric(string fileName)
{
    /*
            this function starts at the beggining of the relations set and looks
        all members of it to find its symetric if it can find it increase the checker
        if checker equals to size of relations it means that it is symetric.
            Algorithm looks like
                compared:A**              temp**
                          ^                    ^
                if it is true and
                compared:A**              temp**
                           ^                  ^
            it is true so they are reflexive.
            in little for if algorithm can not finds the symetric of it it writes
        it has not symetric relation
    */
    int checker=0;//checker is 0 like reflexive function
    ofstream file;
    file.open(fileName,ios::app);//for adding 
    for (int i = 0; i < size; i++)//two for because I am looking all relations for each relation
    {
        bool tempChecker=false;//it is easier to look tempChecker changes when it is boolean
        for (int j = 0; j < size; j++)
        {
            if (set_of_Relations[i][0]==set_of_Relations[j][1]&&set_of_Relations[i][1]==set_of_Relations[j][0])
            {//this set_of_Relations[i][0]==set_of_Relations[j][1] operation works if it is reflexive too
                checker++;
                tempChecker=true;
            }
        }
    }

        if (checker==size){//if everyone has symetric 
                isSymetric=true;
            }
        else{
                isSymetric=false;
            }
    file.close();
}
void Set::checkAnti(string fileName)//checkes for antisymetric
{
    ofstream file;
    file.open(fileName,ios::app);
    bool antiChecker=true;
    for (int i = 0; i < size; i++)//look every relation for each relation
    {
        bool tempAnti=true;
        if(set_of_Relations[i][0]!=set_of_Relations[i][1])//if it is reflexive do not care it
        {
            for (int j = 0; j < size; j++)
            {
                if(set_of_Relations[i][0]==set_of_Relations[j][1]&&set_of_Relations[i][1]==set_of_Relations[j][0])
                {//if we have symetric(reflexive is symetric too but I sad it in the if's comment) it can not be antisymetric
                    antiChecker=false;//so make antichecker false
                    tempAnti=false;
                }
            }
            if(tempAnti==false){//If code realises that is not antisymetric write it at file
                //in here I change the unwanted relation with last and decreas the size
                //so the last and unwanted relation no longer exists
                set_of_Relations[i][0]=set_of_Relations[size-1][0];//it is the transportation
                set_of_Relations[i][1]=set_of_Relations[size-1][1];
                size--;
            }
        }
    }
    if(antiChecker){//if antichecker is true write antisymetric else not antisymetric
        isAntisymetric=true;
        }
    else{
        isAntisymetric=false;
        }
    file.close();
}
void Set::checkTransitive(string fileName)
{
    ofstream file;
    file.open(fileName,ios::app);
    bool trans=true;//same logic with other functions
    for (int i = 0; i < size; i++)//this for loop is for look every relations for each relation
    {
        if (set_of_Relations[i][0]!=set_of_Relations[i][1])//if it is reflexive do not care it
        {
            for (int j = 0; j < size;j++)
            {
                if(set_of_Relations[j][1]!=set_of_Relations[j][0]&&set_of_Relations[i][1]==set_of_Relations[j][0])//if the set have relations like(a,b)and (b,d)
                {
                    bool tempCheck=false;
                    for (int k = 0; k< size; k++)//this for loop is for searching the (a,d)
                    {
                        if (set_of_Relations[k][0]==set_of_Relations[i][0]&&set_of_Relations[k][1]==set_of_Relations[j][1])
                        {
                            tempCheck=true;//it means we found the transitive one 
                            //in here I hold the position of the one and when I will write the
                            //hasse I will not write it
                            whereisTheTransitivity.push_back(k);
                        }
                    }
                    if (!tempCheck){//if tempcheck is false
                        trans=false;
                        set_of_Relations.resize(size+1);//I here adding the transitive one
                        set_of_Relations[size].resize(2);
                        set_of_Relations[size][0]=set_of_Relations[i][0];
                        set_of_Relations[size][1]=set_of_Relations[j][1];
                        whereisTheTransitivity.push_back(size);
                        size++;
                        }
                }
            }
        }        
    }
    if(trans){
        isTransitive=true;
        }
    else{
        isTransitive=false;
        }
    file.close();
}
void Set::chechkPoset(string fileName){
    ofstream file;
    file.open(fileName,ios::app);
    if(isTransitive&&isReflexive&&isAntisymetric){
        isPoset=true;
    }
    else
    {
        isPoset=false;
    }
    file.close();
}
ostream &operator<<(ostream &out,Set temp)
{//I did this operator overloading for test before I print at the output and I did not delete it because
//it is harmless and helpful
    out<<"Size:"<<temp.getSize()<<endl;//writing size
    cout<<"there are "<<temp.howManyElement<<" elements"<<endl<<"Elements:"<<endl;
    temp.printElements();//it writes elements
    temp.printRelations();//and relations
    return out;
}
void Set::writeNewRelationSet(string fileName)
{
    ofstream file;
    file.open(fileName,ios::app);
   file<<"POSET: ";
    for (int i = 0; i < size; i++)
    {
        file<<"("<<set_of_Relations[i][0]<<","<<set_of_Relations[i][1]<<")  ";
    }
    
    file.close();
}
void Set::writeHasse(string fileName){
    ofstream file;
    file.open(fileName,ios::app);
    for (int i = 0; i < size; i++)//in here I test all of the set of arrays
    {
        bool canIwrite=false;//creating bool for can I write in hasse
        if(set_of_Relations[i][0]!=set_of_Relations[i][1])//if it is transitive I should not write it
        {//and I do not have to check it's transitivity so bool is false and I will do not write it
            canIwrite=true;//it is not reflexive so make it true for a second
            for (int j = 0; j < whereisTheTransitivity.size(); j++)
            {//I hold the transitivities positions already so it will be much easier for test
                if(i==whereisTheTransitivity[j])
                    canIwrite=false;//if the position is not ok make the canIwrite false again 
            }
        }
        if(canIwrite)
            file<<endl<<set_of_Relations[i][0]<<','<<set_of_Relations[i][1];//if can I write I am writing
    }
    file.close();
    file.close();
    
}